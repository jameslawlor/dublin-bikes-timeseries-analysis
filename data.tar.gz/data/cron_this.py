print("Test")
import datetime
today = datetime.datetime.now().strftime("%Y-%m-%d_%H_%M")
fout = open("/home/james/Documents/aws_test/Dublin-Bikes-Analysis/cron_test/"+str(today),"w")
fout.close()
